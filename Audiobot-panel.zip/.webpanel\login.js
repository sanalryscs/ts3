var sifre=prompt("Şifrenizi Giriniz");
if(sifre=="sanal.123er")
{

}
else
{
document.write("Şifre hatalı");
 window.location.reload("/index.html")
}