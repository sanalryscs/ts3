var sifre=prompt("Şifrenizi Giriniz");
if(sifre=="1")
{

}
else
{
document.write("Şifre hatalı");
 window.location.reload("/index.html")
}